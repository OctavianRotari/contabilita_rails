$(document).ready(function(){
	function category_fails_to_save(){
		$('#category').find('#pop_up').trigger('click');
	}
});
