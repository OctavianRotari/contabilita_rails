$(document).ready(function(){
  $('.success').addClass('visible');
});
