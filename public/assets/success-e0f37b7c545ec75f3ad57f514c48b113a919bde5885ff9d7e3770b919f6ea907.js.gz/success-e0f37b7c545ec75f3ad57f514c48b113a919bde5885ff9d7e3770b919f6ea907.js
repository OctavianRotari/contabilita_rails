$(document).ready(function(){
	$('.success').addClass('visible');
	$('.success').addClass('animated tada');
});
